# -*- coding: utf-8 -*-
"""
thi_quiz.py

Created on Tue Nov 23 22:27:53 2021

@author: 
"""

import thi_quiz_data
import thi_quiz_gui